
Zip this folder after building the samplePlugin project
